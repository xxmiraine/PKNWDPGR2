using System;

class MainClass {
  public static void Main (string[] args) {
    Console.WriteLine ("Hello, strangers!");

    Console.WriteLine ("What's your name, Player one?");
     string PlayerOne = Console.ReadLine();

     Console.WriteLine ("Sup, " + PlayerOne);
    
     Console.WriteLine ("And yours, Player two?");
     string PlayerTwo = Console.ReadLine();

     Console.WriteLine ("Nice to meet ya, " + PlayerTwo);
     Console.WriteLine ("Get yourself ready!");
    
    Console.WriteLine (PlayerOne + "Choose your weapon - R, P, S?");
     string ChoiceOne = Console.ReadLine();
     Console.Clear();

    Console.WriteLine (PlayerTwo + "Choose your weapon - R, P, S?");
     string ChoiceTwo = Console.ReadLine();

     if {FirstSign == "R" && ChoiceTwo == "S"}{
       Console.WriteLine("Result: " + PlayerOne + "wins");
     })

  }
}
